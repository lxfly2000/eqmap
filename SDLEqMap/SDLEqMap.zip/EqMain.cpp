﻿#ifdef _MSC_VER
#include"UseUTF-8.h"
#include"UseVisualStyle.h"
#endif // _MSC_VER

#include<string>
#include<vector>
#include<fstream>
#include<Windows.h>
#include<SDL.h>
#include<SDL_image.h>
#include<SDL_mixer.h>
#include"MySDL2.h"
#include"MyUtilities.h"
#include"AudioSample.hpp"

#define EVENTCODE_FPS 100

int VideoFramesToAudioSample(int frame, int hz, int fps)
{
	return frame * hz / fps;
}

//http://blog.csdn.net/chinahaerbin/article/details/7767226
std::string GetUTF8StringFromGBK(std::string strGBK)
{
	std::string strUTF8;
	int len = MultiByteToWideChar(CP_ACP, 0, (LPCSTR)strGBK.c_str(), -1, NULL, 0);
	unsigned short * wszUtf8 = new unsigned short[len + 1];
	memset(wszUtf8, 0, len * 2 + 2);
	MultiByteToWideChar(CP_ACP, 0, (LPCSTR)strGBK.c_str(), -1, (LPWSTR)wszUtf8, len);
	len = WideCharToMultiByte(CP_UTF8, 0, (LPCWSTR)wszUtf8, -1, NULL, 0, NULL, NULL);
	char *szUtf8 = new char[len + 1];
	memset(szUtf8, 0, len + 1);
	WideCharToMultiByte(CP_UTF8, 0, (LPCWSTR)wszUtf8, -1, szUtf8, len, NULL, NULL);
	//strGBK = szUtf8; 
	strUTF8 = szUtf8;
	delete[] szUtf8;
	delete[] wszUtf8;
	return strUTF8;
}

BOOL SelectFile(TCHAR *filepath, TCHAR *filename)
{
	OPENFILENAME ofn = { sizeof OPENFILENAME };
	ofn.lStructSize = sizeof OPENFILENAME;
	ofn.hwndOwner = GetActiveWindow();
	ofn.hInstance = nullptr;
	ofn.lpstrFilter = "\xCB\xF9\xD3\xD0\xCE\xC4\xBC\xFE\0*\0\0";
	ofn.lpstrFile = filepath;
	ofn.lpstrTitle = "\xD1\xA1\xD4\xF1\xCE\xC4\xBC\xFE";
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = filename;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.Flags = OFN_HIDEREADONLY;
	ofn.lpstrDefExt = "";
	return GetOpenFileName(&ofn);
}

struct TimeType
{
	short year, month, day, hour, minute;
	static TimeType ParseDate(const char* str)
	{
		TimeType t = { 0 };
		SDL_sscanf(str, "%d-%d-%d", &t.year, &t.month, &t.day);
		return t;
	}
	static TimeType ParseTime(const char* str)
	{
		TimeType t = { 0 };
		SDL_sscanf(str, "%d:%d", &t.hour, &t.minute);
		return t;
	}
	void SetDateByString(const char* str)
	{
		SDL_sscanf(str, "%d/%d/%d", &year, &month, &day);
	}
	void SetTimeByString(const char* str)
	{
		SDL_sscanf(str, "%d:%d", &hour, &minute);
	}
	//当天发生变化时返回真
	bool GoForward(int speed_in_minute)
	{
		minute += speed_in_minute;
		if (minute < 60)return false;
		hour += minute / 60;
		minute = minute % 60;
		if (hour < 24)return false;
		day++;
		hour = 0;
		if (day < 29)return true;
		switch (month)
		{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			if (day == 32)
			{
				day = 1;
				month++;
			}
			break;
		case 4: case 6: case 9: case 11:
			if (day == 31)
			{
				day = 1;
				month++;
			}
			break;
		case 2:
			if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
			{
				if (day == 30)
				{
					day = 1;
					month++;
				}
			}
			else
			{
				if (day == 29)
				{
					day = 1;
					month++;
				}
			}
			break;
		}
		if (month < 13)return true;
		year++;
		month = 1;
		return true;
	}
	//是否比另一个时间早，在另一个时间的前面（1日在2日前面）
	bool EarlierThan(const TimeType& timeAnother)
	{
		if (year < timeAnother.year)return true;
		if (year > timeAnother.year)return false;
		if (month < timeAnother.month)return true;
		if (month > timeAnother.month)return false;
		if (day < timeAnother.day)return true;
		if (day > timeAnother.day)return false;
		if (hour < timeAnother.hour)return true;
		if (hour > timeAnother.hour)return false;
		if (minute < timeAnother.minute)return true;
		//if (minute > timeAnother.minute)return false;
		//if (second < timeAnother.second)return true;
		return false;
	}
	//是否比另一个时间晚，在另一个时间的后面（2日在1日后面）
	bool LaterThan(const TimeType& timeAnother)
	{
		return !EarlierThan(timeAnother);
	}
};

struct EqEntryType
{
	TimeType eq_eqTime;//时间
	float eq_magnitude;//震级
	float eq_longitude;//经度
	float eq_latitude;//纬度
	float eq_depth;//深度
	std::string eq_location;//发生地点的文字描述

	float il_size;//在图上表示的圈的半径
	float il_rotation;//在图上表示的圈的倾斜角
	SDL_Point il_position;//在图上表示的圈的位置
	SDL_Color il_color;//在图上表示的圈的颜色（含透明度，随 il_frameleft 变化）
	int il_frameleft;//在图上表示的圈剩余显示帧数
	std::string il_strSummary;//文字描述

	static EqEntryType GetDataFromString(std::string str, const SDL_Rect& mapSize, float K, float B,
		float longitudeLeft, float longitudeRight, float latitudeTop, float latitudeBottom)
	{
		EqEntryType eq;
		size_t pos = str.find_first_of(' ');
		eq.eq_eqTime.SetDateByString(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_eqTime.SetTimeByString(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_longitude = (float)SDL_atof(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_latitude = (float)SDL_atof(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_depth = (float)SDL_atof(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		//跳过震级类型
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_magnitude = (float)SDL_atof(str.substr(0, pos).c_str());
		str = str.substr(pos + 1);
		pos = str.find_first_of(',');
		eq.eq_location = str.substr(pos + 1);
		//跳过事件类型

		eq.il_size = 3.54f*expf(0.45f*eq.eq_magnitude);
		eq.il_rotation = 0.38f*sqrtf(80.0f*eq.eq_depth);
		eq.il_position.x = (int)((eq.eq_longitude - longitudeLeft)*mapSize.w / (longitudeRight - longitudeLeft));
		eq.il_position.y = (int)(K*log((1.0 + sin(DegToRad(eq.eq_latitude))) /
			cos(DegToRad(eq.eq_latitude))) + B);//平面直角坐标与像素坐标转换
		eq.il_color.a = 255;
		eq.il_color.r = (Uint8)(255.0f*expf(eq.eq_depth*(-0.02f)));
		eq.il_color.b = eq.il_color.g = 0;
		eq.il_frameleft = 90;

		if (eq.eq_magnitude >= 5.0f)
		{
			char str[256];
			SDL_snprintf(str, SDL_arraysize(str), "%2d-%2d %2d:%02d%6.1f\xF8%5.1f\xF8 M%3.1f %3.0fkm %s",
				eq.eq_eqTime.month, eq.eq_eqTime.day, eq.eq_eqTime.hour, eq.eq_eqTime.minute,
				eq.eq_longitude, eq.eq_latitude, eq.eq_magnitude, eq.eq_depth, eq.eq_location.c_str());
			eq.il_strSummary = str;
			if ((int)eq.il_strSummary.size() > maxLogStrLen)maxLogStrLen = (int)eq.il_strSummary.size();
		}
		return eq;
	}
	void DrawCircle(SDL_Renderer* renderer, SDL_Texture* img)
	{
		SDL_SetTextureAlphaMod(img, il_color.a);
		SDL_SetTextureColorMod(img, il_color.r, il_color.g, il_color.b);
		MySDL2::DrawImage(renderer, img, il_position.x - (int)il_size, il_position.y - (int)il_size,
			(int)il_size * 2, (int)il_size * 2, il_rotation);
	}
	void PutLogPoint(SDL_Renderer* renderer)
	{
		SDL_SetRenderDrawColor(renderer, 240, 240, 12, 128);
		SDL_RenderDrawPoint(renderer, il_position.x, il_position.y);
	}
	void DrawMagnitude(SDL_Renderer* renderer)
	{
		using namespace MySDL2::ASCII_px_6x8;
		SDL_snprintf(strbuffer, SDL_arraysize(strbuffer), "%.1f", eq_magnitude);
		pxsize = (int)il_size / 20;
		x = il_position.x - pxsize * px_count_horizonal * 3 / 2;
		y = il_position.y - pxsize * px_count_vertical / 2;
		DrawPxString(renderer, strbuffer, SDL_arraysize(strbuffer), x, y, pxsize, { 32,32,6,il_color.a });
		DrawPxString(renderer, strbuffer, SDL_arraysize(strbuffer), x - 2, y - 2, pxsize, { 240,240,12,il_color.a });
	}
	void Update()
	{
		il_frameleft--;
		il_color.a = 255 * SDL_min(50, il_frameleft) / 50;
	}
	static int GetMaxLogStrLen()
	{
		return maxLogStrLen;
	}
private:
	static char strbuffer[6];
	static int pxsize, x, y;
	static int maxLogStrLen;
};
char EqEntryType::strbuffer[] = "";
int EqEntryType::pxsize = 0;
int EqEntryType::x = 0;
int EqEntryType::y = 0;
int EqEntryType::maxLogStrLen = 0;

struct LogStrType
{
	LogStrType()
	{
		strLength = new int[GetLogNum()];
	}
	~LogStrType()
	{
		delete[GetLogNum()]strLength;
	}
	void AddString(const char* str)
	{
		strLogs[cursor] = str;
		strLength[cursor] = (int)SDL_strlen(str);
		cursor = (cursor + 1) % SDL_arraysize(strLogs);
	}
	void DrawString(SDL_Renderer* renderer, int x, int y, int pxsize, SDL_Color color)
	{
		for (int i = 0; i < SDL_arraysize(strLogs); i++)
		{
			using namespace MySDL2::ASCII_px_6x8;
			tempi = (cursor + i) % SDL_arraysize(strLogs);
			DrawPxString(renderer, strLogs[tempi], strLength[tempi], x + 2, y + i * px_count_vertical * pxsize + 2,
				pxsize, { (Uint8)(color.r / 4),(Uint8)(color.g / 4),(Uint8)(color.b / 4),color.a });
			DrawPxString(renderer, strLogs[tempi], strLength[tempi], x, y + i * px_count_vertical * pxsize, pxsize, color);
		}
	}
	int GetLogNum()
	{
		return SDL_arraysize(strLogs);
	}
private:
	const char* strLogs[5];
	int tempi;
	int cursor = 0;
	int *strLength;
};

class EqProgram
{
public:
	EqProgram() :szEqTitle("地震分布"), windowRect({ 0,0,1280,720 }),sfx(NULL),audioMaster(NULL)
	{
		SDL_Init(SDL_INIT_EVERYTHING);
		IMG_Init(IMG_INIT_PNG);
		Mix_Init(NULL);
	}
	~EqProgram()
	{
		Mix_Quit();
		IMG_Quit();
		SDL_Quit();
	}
	SDL_Window*GetEqWindow()const
	{
		return pWindow;
	}
	void Init(const char* pathFile)
	{
#define CHECK_LOAD(obj,file) if(!obj){SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, file, "该文件无法读取。", pWindow);return;}
		pWindow = SDL_CreateWindow(szEqTitle.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
			windowRect.w, windowRect.h, SDL_WINDOW_SHOWN);
		std::ifstream fileInConfig(pathFile, std::ios::in);
		CHECK_LOAD(fileInConfig, pathFile);
		std::string strbuffer, pathData;
		pRenderer = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
		std::getline(fileInConfig, strbuffer);
		pImgBgMap = IMG_LoadTexture(pRenderer, strbuffer.c_str());
		CHECK_LOAD(pImgBgMap, strbuffer.c_str());
		std::getline(fileInConfig, strbuffer);
		pathData = strbuffer;
		fileInConfig >> speedPerFrame >> currentWeek >> strbuffer;
		currentTime = TimeType::ParseDate(strbuffer.c_str());
		fileInConfig >> strbuffer;
		endTime = TimeType::ParseDate(strbuffer.c_str());
		fileInConfig >> showLogPoint >> useGMT >> showLogList;
		fileInConfig >> longitudeLeft >> longitudeRight >> latitudeTop >> latitudeBottom >> recordAudio;
		paramK = (float)(windowRect.h / (log((1.0 + sin(DegToRad(latitudeBottom))) / cos(DegToRad(latitudeBottom))) -
			log((1.0 + sin(DegToRad(latitudeTop))) / cos(DegToRad(latitudeTop)))));
		paramB = (float)(paramK*(-log((1.0 + sin(DegToRad(latitudeTop))) / cos(DegToRad(latitudeTop)))));
		CHECK_LOAD(LoadData(pathData.c_str()), pathData.c_str());

		pImgCircle = IMG_LoadTexture(pRenderer, fileImgCircle);
		CHECK_LOAD(pImgCircle, fileImgCircle);
		pStatLine = SDL_CreateTexture(pRenderer, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET,
			windowRect.w, windowRect.h);
		SDL_SetTextureBlendMode(pStatLine, SDL_BLENDMODE_BLEND);
		pLogPoints = SDL_CreateTexture(pRenderer, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_TARGET,
			windowRect.w, windowRect.h);
		SDL_SetTextureBlendMode(pLogPoints, SDL_BLENDMODE_BLEND);
		SDL_SetRenderDrawBlendMode(pRenderer, SDL_BLENDMODE_BLEND);

		totalFrames = (int)((endTime.year - currentTime.year) * 365.25 * 24 * 60 / speedPerFrame);//粗略计算
		lastStatLineX = blankLeft;
		lastStatLineY = windowRect.h - blankBottom;
		statLineTop = blankTop + pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_vertical;

		if (useGMT)SDL_strlcat(fmtStrTime, " GMT", SDL_arraysize(fmtStrTime));

		timerFPS = SDL_AddTimer(1000, [](Uint32 interval, void* param)
		{
			SDL_Event se;
			SDL_UserEvent sue;
			sue.type = SDL_USEREVENT;
			sue.code = EVENTCODE_FPS;
			sue.data1 = nullptr;
			sue.data2 = nullptr;
			se.type = SDL_USEREVENT;
			se.user = sue;

			SDL_PushEvent(&se);
			return interval;
		}, nullptr);
		Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024);
		for (numSFXFiles = 0; numSFXFiles < SDL_arraysize(pEqSFX); numSFXFiles++)
		{
			char str[32];
			SDL_snprintf(str, SDL_arraysize(str), fileSFX, numSFXFiles);
			pEqSFX[numSFXFiles] = Mix_LoadWAV(str);
			if (numSFXFiles == 0)
			{
				CHECK_LOAD(pEqSFX[numSFXFiles], str);
			}
			else if (!pEqSFX[numSFXFiles])
			{
				break;
			}
		}
		if (recordAudio)
		{
			sfx = new AudioSample("sfx0.wav");
			audioMaster = new AudioSample(2, 44100);
			audioMaster->Resize(VideoFramesToAudioSample(totalFrames + 300, 44100, 60));
		}
		isRunning = true;
	}
	void Run()
	{
		SDL_Event e;
		while (isRunning)
		{
			while (SDL_PollEvent(&e))
			{
				switch (e.type)
				{
				case SDL_QUIT:isRunning = false; break;
				case SDL_KEYDOWN:
					switch (e.key.keysym.sym)
					{
					case SDLK_ESCAPE:isRunning = false; break;
					case SDLK_F11:
						fullscreen ^= SDL_WINDOW_FULLSCREEN_DESKTOP;
						SDL_SetWindowFullscreen(pWindow, fullscreen);
						break;
					}
					break;
				case SDL_USEREVENT:
					switch (e.user.code)
					{
					case EVENTCODE_FPS:OnCalcFPS(); break;
					}
					break;
				}
			}

			SDL_RenderClear(pRenderer);
			OnDraw();
			SDL_RenderPresent(pRenderer);
		}
	}
	int End()
	{
		if (recordAudio)
		{
			audioMaster->SaveToFile("audio.wav");
			if (sfx)
				delete sfx;
			if (audioMaster)
				delete audioMaster;
		}
		SDL_RemoveTimer(timerFPS);
		for (int i = 0; i < numSFXFiles; i++)Mix_FreeChunk(pEqSFX[i]);
		Mix_CloseAudio();
		SDL_DestroyTexture(pStatLine);
		SDL_DestroyTexture(pLogPoints);
		SDL_DestroyTexture(pImgCircle);
		SDL_DestroyTexture(pImgBgMap);
		SDL_DestroyRenderer(pRenderer);
		SDL_DestroyWindow(pWindow);
		return 0;
	}
	const std::string szEqTitle;
	const SDL_Rect windowRect;
private:
	bool LoadData(const char* file)
	{
		std::string strbuffer;
		std::ifstream fileInData(file, std::ios::in);
		if (!fileInData)return false;
		while (!fileInData.eof())
		{
			std::getline(fileInData, strbuffer);
			if (isdigit(strbuffer[0]&0xFF))
			{
				const EqEntryType& eqe = EqEntryType::GetDataFromString(strbuffer, windowRect, paramK, paramB,
					longitudeLeft, longitudeRight, latitudeTop, latitudeBottom);
				if (eqe.eq_magnitude >= 2.0f)
					earthquakes.insert(earthquakes.begin(), 1, eqe);
			}
		}
		return true;
	}
	void OnDraw()
	{
		if (frozenStartFrames)
		{
			frozenStartFrames--;
		}
		else if (cursorCurEq < earthquakes.size())
		{
			if (currentTime.GoForward(speedPerFrame))currentWeek = (currentWeek + 1) % 7;
			while (earthquakes[cursorCurEq].eq_eqTime.EarlierThan(currentTime))
			{
				if (earthquakes[cursorCurEq].il_strSummary.size())
					logStr.AddString(earthquakes[cursorCurEq].il_strSummary.c_str());
				PlaySFX(earthquakes[cursorCurEq]);
				if (recordAudio && earthquakes[i].eq_magnitude >= 2.0f)
				{
					AudioSample smp = *sfx;
					audioMaster->Seek(VideoFramesToAudioSample(frameCounter, 44100, 60))->Mix(smp.Pan(2.0f * earthquakes[i].il_position.x / windowRect.w - 1.0f)->
						Speed(1.0f - 0.5f * earthquakes[i].il_rotation / 90.0f)->Volume(std::min(200.0f, earthquakes[i].il_size) / 200.0f));
				}
				cursorCurEq++;
				if (cursorCurEq >= earthquakes.size())break;
			}
			currentFrame++;
		}
		MySDL2::DrawImage(pRenderer, pImgBgMap, 0, 0);
		if (showLogPoint)MySDL2::DrawImage(pRenderer, pLogPoints, 0, 0);
		for (i = cursorTailEq; i < cursorCurEq; i++)
		{
			SDL_SetRenderTarget(pRenderer, pLogPoints);
			earthquakes[i].PutLogPoint(pRenderer);
			SDL_SetRenderTarget(pRenderer, NULL);
			earthquakes[i].DrawCircle(pRenderer, pImgCircle);
			earthquakes[i].Update();
			if (!earthquakes[i].il_frameleft)cursorTailEq = i + 1;
		}
		OnDrawStatLine();
		for (i = cursorTailEq; i < cursorCurEq; i++)
			earthquakes[i].DrawMagnitude(pRenderer);
		SDL_snprintf(strTime, SDL_arraysize(strTime), fmtStrTime, currentTime.year, currentTime.month,
			currentTime.day, strWeeks[currentWeek], currentTime.hour, currentTime.minute);
		if (showLogList)logStr.DrawString(pRenderer,
			windowRect.w - blankRight - EqEntryType::GetMaxLogStrLen() * pxSizeLogStr * MySDL2::ASCII_px_6x8::px_count_horizonal,
			windowRect.h - blankBottom - logStr.GetLogNum() * MySDL2::ASCII_px_6x8::px_count_vertical * pxSizeLogStr,
			pxSizeLogStr, { 255,255,255,180 });
		MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTime, SDL_arraysize(strTime),
			blankLeft + pxSizeTime, blankTop + pxSizeTime, pxSizeTime, { 40,40,40,120 }, true);
		MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTime, SDL_arraysize(strTime),
			blankLeft, blankTop, pxSizeTime, { 255,255,255,180 }, true);
		fpsCounter++;
		frameCounter++;
	}
	void OnDrawStatLine()
	{
		SDL_SetRenderTarget(pRenderer, pStatLine);
		statLineX = blankLeft + (windowRect.w - blankLeft - blankRight) * currentFrame / totalFrames;
		statLineY = windowRect.h - blankBottom - (windowRect.h - blankBottom - statLineTop) * cursorCurEq / (int)earthquakes.size();
		SDL_RenderDrawLine(pRenderer, lastStatLineX, lastStatLineY, statLineX, statLineY);
		SDL_SetRenderTarget(pRenderer, NULL);
		MySDL2::DrawImage(pRenderer, pStatLine, 0, 0);
		SDL_snprintf(strTime, SDL_arraysize(strTime), "%6d", cursorCurEq);
		i = (int)SDL_strlen(strTime);
		MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTime, SDL_arraysize(strTime),
			statLineX - i * pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_horizonal + 2,
			statLineY - pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_vertical + 2, pxSizeCounter, { 40,40,40,120 });
		MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTime, SDL_arraysize(strTime),
			statLineX - i * pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_horizonal,
			statLineY - pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_vertical, pxSizeCounter, { 255,255,255,180 });
		if (frameLeftStrTotalCount && !frozenStartFrames)
		{
			const char strTotalCount[] = "(Total Counts)";
			MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTotalCount, SDL_arraysize(strTotalCount), statLineX + 2,
				statLineY - pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_vertical + 2, pxSizeCounter,
				{ 40,40,40,(Uint8)(120 * SDL_min(frameLeftStrTotalCount,60) / 60) });
			MySDL2::ASCII_px_6x8::DrawPxString(pRenderer, strTotalCount, SDL_arraysize(strTotalCount), statLineX,
				statLineY - pxSizeCounter * MySDL2::ASCII_px_6x8::px_count_vertical, pxSizeCounter,
				{ 255,255,255,(Uint8)(180 * SDL_min(frameLeftStrTotalCount,60) / 60) });
			frameLeftStrTotalCount--;
		}
		lastStatLineX = statLineX;
		lastStatLineY = statLineY;
	}
	void OnCalcFPS()
	{
		SDL_snprintf(strTime, SDL_arraysize(strTime), "%s FPS:%3d", szEqTitle.c_str(), fpsCounter);
		SDL_SetWindowTitle(pWindow, strTime);
		fpsCounter = 0;
	}
	void PlaySFX(const EqEntryType& eq)
	{
		Uint8 posl = 255 * eq.il_position.x / windowRect.w;
		int soundno = (int)eq.il_rotation*numSFXFiles / 90;
		Mix_SetPanning(MIX_CHANNEL_POST, 255 - posl, posl);
		Mix_VolumeChunk(pEqSFX[soundno], 128 * SDL_min(200, (int)eq.il_size) / 200);
		Mix_PlayChannel(-1, pEqSFX[soundno], 0);
	}
	LogStrType logStr;
	SDL_Window* pWindow;
	SDL_Renderer* pRenderer;
	SDL_TimerID timerFPS;
	SDL_Texture* pImgBgMap, *pImgCircle, *pStatLine, *pLogPoints;
	Mix_Chunk* pEqSFX[12];//数值越大声音越低
	int speedPerFrame;//每帧前进多少分钟
	TimeType currentTime;
	TimeType endTime;
	int currentWeek;
	bool showLogPoint, useGMT, showLogList, isRunning = false;
	float longitudeLeft, longitudeRight, latitudeTop, latitudeBottom;
	int recordAudio = 0;
	float paramK, paramB;//用于平面直角坐标与像素点关系的线性公式的参数
	std::vector<EqEntryType>earthquakes;
	AudioSample *sfx,*audioMaster;

	int fullscreen = 0;
	int fpsCounter = 0, frameCounter = 0;
	int frozenStartFrames = 60;
	int cursorCurEq = 0, cursorTailEq = 0, statLineTop = 0;
	int currentFrame = 0, totalFrames = 0, lastStatLineX = 0, lastStatLineY = 0, statLineX = 0, statLineY = 0;
	const int blankLeft = 28, blankRight = 18, blankTop = 12, blankBottom = 12;
	const int pxSizeCounter = 3, pxSizeLogStr = 2, pxSizeTime = 4;
	int pxHeightCounter, pxHeightLogStr, pxHeightTime;
	int i = 0;
	int frameLeftStrTotalCount = 600;
	int numSFXFiles = 0;
	char strTime[32];
	char fmtStrTime[32] = "%4d-%2d-%2d %s\n%02d:%02d";
	const char strWeeks[7][4] = { "Sun","Mon","Tue","Wed","Thu","Fri","Sat" };
	const char fileSFX[10] = "sfx%d.wav", fileImgCircle[11] = "circle.png";
};

int main(int argc, char *argv[])
{
	EqProgram eqMain;
	if (argc != 2)
	{
		TCHAR filepath[MAX_PATH] = "";
		SelectFile(filepath, NULL);
		if (SDL_strlen(filepath) == 0)
		{
			SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_INFORMATION, eqMain.szEqTitle.c_str(),
				"请指定数据文件。", eqMain.GetEqWindow());
			return 1;
		}
		else
		{
			eqMain.Init(GetUTF8StringFromGBK(filepath).c_str());
		}
	}
	else
	{
		eqMain.Init(argv[1]);
	}
	eqMain.Run();
	return eqMain.End();
}