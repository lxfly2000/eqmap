﻿#define MYSDL2_NO_FONT
//#define MYSDL2_NO_PX_FONT

namespace MySDL2
{
	//绘制图像
	//srcRect: 图像区域，为空表示使用整个图像
	//x, y, w, h: 以图像左上角为原点的绘制区域，图像区域会缩放至绘制区域大小；w, h 至少一个为 0 时绘制区域大小为图像大小
	//rot: 以 cpoint 为中心的顺时针旋转的角度
	//cpoint: 指定旋转中心，默认为图片的中心
	//flip: 指定翻转，默认为不翻转
	//成功返回 0, 出错返回 -1
	extern int DrawImage(SDL_Renderer *renderer, SDL_Texture *img, int x, int y, int w = 0, int h = 0, double rot = 0.0, const SDL_Rect *srcRect = NULL, const SDL_Point *cpoint = NULL, const SDL_RendererFlip flip = SDL_FLIP_NONE);

#ifndef MYSDL2_NO_FONT
	//加载文字，返回图像指针，失败时返回 NULL
	//mlWidth: 存在换行时的图像宽度，即使实际没有达到该宽度，否则为实际宽度，为 0 时使用实际宽度（会消耗大量性能来计算宽度）
	extern SDL_Texture *LoadTextToImage(SDL_Renderer *pRenderer, const char *text, TTF_Font *font, const SDL_Color color, unsigned mlWidth = 0);

	//绘制文字，成功返回 0，否则为 -1
	//最好使用 LoadTextToImage, 然后用 DrawImage 绘制文字
	//mlWidth: 存在换行时的图像宽度，即使实际没有达到该宽度，否则为实际宽度，为 0 时使用实际宽度（会消耗大量性能来计算宽度）
	extern int DrawText(SDL_Renderer *pRenderer, const char *text, int x, int y, TTF_Font *font, const SDL_Color color, unsigned mlWidth = 0);
#endif
#ifndef MYSDL2_NO_PX_FONT
	namespace ASCII_px_6x8 {
		extern const unsigned ch_count;
		extern const int px_count_horizonal, px_count_vertical;

		//绘制单个字符的点阵
		//字符不存在返回 -1, 否则为 0
		extern int DrawPxChar(SDL_Renderer *renderer, unsigned ch, int x, int y, int pxsize);

		//绘制点阵字符串
		//str: 要显示的字符串
		//strsize: 字符串长度（通过 SDL_arraysize 获取）
		//x, y: 文字左上角的座标
		//pxsize: 单个像素的边长
		//color: 填充颜色（如果要使用 Alpha 需要设置混合模式）
		//multiline: 是否允许换行（默认不允许）
		//字符不存在返回 -1, 否则为 0
		extern int DrawPxString(SDL_Renderer *renderer, const char *str, int strsize, int x, int y, int pxsize, const SDL_Color color, bool multiline = false);
	}
#endif
}
