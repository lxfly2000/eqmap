﻿#pragma once
#pragma message("【信息】你在文件中使用了 UTF-8 编码。")
#pragma execution_character_set("UTF-8")			//设定为 UTF-8 大字符集以避免乱码
