﻿#pragma once
//请尽量将本文件的包含语句置后
#define _MY_UTILITIES

//////////////////////////////////////////////////////////////////////////
//编码相关
#define LittleEndianToBigEndianInt(n)			(((n)>>24)&0x000000FF|((n)>>8)&0x0000FF00|((n)<<8)&0x00FF0000|((n)<<24)&0xFF000000)		//大小端转化（4字节）
#define BigEndianToLittleEndianInt(n)			LittleEndianToBigEndianInt(n)				//大小端转化（4字节）
#define LittleEndianToBigEndianShort(n)			(((n)>>8)&0x00FF|((n)<<8)&0xFF00)			//大小端转化（2字节）
#define BigEndianToLittleEndianShort(n)			LittleEndianToBigEndianShort(n)				//大小端转化（2字节）

//////////////////////////////////////////////////////////////////////////
//数学

//浮点数，需要，包含 cmath 或 math.h
#define IsFloatEquals(floatA,floatB,accuracy)	((accuracy)<0.0f?false:((floatA)>(floatB)?(floatA)-(floatB)<=(accuracy):(floatB)-(floatA)<=(accuracy))) //判断两浮点数在给定误差内是否相等
#define MyAbs(x)								((x)<0?-(x):(x))							//绝对值

//平面几何
#define MathSquare(x)							((x)*(x))									//平方
#define MathSquareSum(x1,x2)					(MathSquare(x1)+MathSquare(x2))				//平方和
#define DistanceOfTwoPoints(x1,y1,x2,y2)		sqrt(MathSquareSum((x2)-(x1),(y2)-(y1)))	//两点距离

//常用常量
#ifndef PI
#define PI										3.1415926535897932384626433832795			//圆周率
#endif

//角度、弧度
#define DegToRad(x)								((x)*PI/180)								//角度到弧度转换
#define RadToDeg(x)								((x)*180/PI)								//弧度到角度转换

//////////////////////////////////////////////////////////////////////////
//代码文本化，需要包含 winnt.h
#define STRING_OF(something)					#something									//代码转换成常量字符串
#define STRING_OF_T(something)					TEXT(STRING_OF(something))					//代码转换成常量字符串（带UNICODE判断）

//////////////////////////////////////////////////////////////////////////
//调试跟踪，需要包含 debugapi.h
//F=__FILE__, L=__LINE__, M=message, N="\n"
#define MyTrace_FLMN(message)					OutputDebugString(__FILE__ TEXT(",") STRING_OF_T( __LINE__ ) TEXT(":")),\
												OutputDebugString(message),OutputDebugString(TEXT("\n"))
#define MyTrace_FLM(message)					OutputDebugString(__FILE__ TEXT(",") STRING_OF_T( __LINE__ ) TEXT(":")),\
												OutputDebugString(message)
#define MyTrace_FMN(message)					OutputDebugString(__FILE__ TEXT(":")),\
												OutputDebugString(message),OutputDebugString(TEXT("\n"))
#define MyTrace_FM(message)						OutputDebugString(__FILE__ TEXT(":")),OutputDebugString(message)
#define MyTrace_MN(message)						OutputDebugString(TEXT(":")),\
												OutputDebugString(message),OutputDebugString(TEXT("\n"))
#define MyTrace(message)						OutputDebugString(TEXT(":")),OutputDebugString(message)
#define MyTrace_M								MyTrace
#define MyTraceT_FLMN(message)					MyTrace_FLMN(TEXT(message))
#define MyTraceT_FLM(message)					MyTrace_FLM(TEXT(message))
#define MyTraceT_FMN(message)					MyTrace_FMN(TEXT(message))
#define MyTraceT_FM(message)					MyTrace_FM(TEXT(message))
#define MyTraceT_MN(message)					MyTrace_MN(TEXT(message))
#define MyTraceT(message)						OutputDebugString(TEXT(message))
#define MyTraceT_M								MyTraceT

//////////////////////////////////////////////////////////////////////////
//断言，需要包含 assert.h
#define MyAssert(expression)					assert(expression)

//////////////////////////////////////////////////////////////////////////
//帧与时间转换
#define FramesToTimeInMS(fps,frames)			((frames)*1000/(fps))						//帧转换为时间（毫秒）
#define FramesToTimeInS(fps,frames)				(FramesToTimeInMS(fps,frames)/1000)			//帧转换为时间（秒）
#define TimeInMSToFrames(fps,time)				((time)*(fps)/1000)							//时间（毫秒）转换为帧
#define TimeInSToFrames(fps,time)				TimeInMSToFrames(fps,(time)*1000)			//时间（秒）转换为帧

//////////////////////////////////////////////////////////////////////////
//需要考虑扩缩率的尺寸、长度等类型变量的转换
#define NumWithZoomRate(num,zoom)				((num)*(zoom))

//////////////////////////////////////////////////////////////////////////
//字符串长度，数组大小
#define VarSet_Length(varset)					(sizeof(varset)/sizeof(*(varset)))
#define String_Length							VarSet_Length

//////////////////////////////////////////////////////////////////////////
//快速对话框
#define ErrorBox(hwnd,info)						MessageBox(hwnd,info,NULL,MB_ICONERROR)
#define ErrorBox_T(hwnd,info)					ErrorBox(hwnd,TEXT(info))
#define ErrorBoxTrace(hwnd,info)				MyTrace_FLMN(info),ErrorBox(hwnd,info)
#define ErrorBox_Res(hwnd,szBuf,strResID)		LoadString(NULL,strResID,szBuf,String_Length(szBuf)),ErrorBox(hwnd,szBuf)
#define ErrorBoxTrace_Res(hwnd,szBuf,strResID)	LoadString(NULL,strResID,szBuf,String_Length(szBuf)),\
												MyTraceT_FLMN(szBuf),ErrorBox(hwnd,szBuf)
#define QuestionYesNoBox(hwnd,info,title)		MessageBox(hwnd,info,title,MB_ICONQUESTION|MB_YESNO)
#define Quick_ErrorBox(info)					ErrorBox(NULL,info)
#define Quick_ErrorBoxTrace(info)				ErrorBoxTrace(NULL,info)
#define Quick_ErrorBox_T(info)					Quick_ErrorBox(TEXT(info))
#define Quick_ErrorBox_Res(szBuf,strResID)		ErrorBox_Res(NULL,szBuf,strResID)
#define Quick_ErrorBoxTrace_Res(szBuf,strResID)	ErrorBoxTrace_Res(NULL,szBuf,strResID)

extern void Quick_ErrorBox_Res_F(int strResID);

//////////////////////////////////////////////////////////////////////////
//快速高级对话框（需要 CommCtrl.h, ComCtl32.lib）
//参考：https://msdn.microsoft.com/en-us/library/windows/desktop/bb760540(v=vs.85).aspx
#define TDBox(hwnd,info,info_title,title,icon)	TaskDialog(hwnd,NULL,title,info_title,info,TDCBF_OK_BUTTON,icon,NULL)
#define ErrorTDBox(hwnd,info,info_title,title)	TDBox(hwnd,info,info_title,title,TD_ERROR_ICON)
#define InfoTDBox(hwnd,info,info_title,title)	TDBox(hwnd,info,info_title,title,TD_INFORMATION_ICON)
#define WarningTDBox(hwnd,info,info_title,title)	TDBox(hwnd,info,info_title,title,TD_WARNING_ICON)
#define SafetyTDBox(hwnd,info,info_title,title)	TDBox(hwnd,info,info_title,title,TD_SHIELD_ICON)
#define TDBox_Error								ErrorTDBox
#define TDBox_Info								InfoTDBox
#define TDBox_Warning							WarningTDBox
#define TDBox_AdminPermission					SafetyTDBox
//pIntButton 返回值可以是 0, IDYES, IDNO, IDOK, IDCANCEL, IDRETRY
#define TDBox_YesNo(hwnd,info,info_title,title,icon,pIntButton)	TaskDialog(hwnd,NULL,title,info_title,info,TDCBF_YES_BUTTON|TDCBF_NO_BUTTON,icon,pIntButton)
#define TDBox_YesNoWarning(hwnd,info,info_title,title,pIntButton)	TDBox_YesNo(hwnd,info,info_title,title,TD_WARNING_ICON,pIntButton)
#define TDBox_YesNoInfo(hwnd,info,info_title,title,pIntButton)	TDBox_YesNo(hwnd,info,info_title,title,TD_INFORMATION_ICON,pIntButton)

//////////////////////////////////////////////////////////////////////////
//Windows Html Help 帮助系统（需要 HtmlHelp.h, HtmlHelp.lib）
#define OpenChm(hwnd,file_url)					HtmlHelp(hwnd,file_url,HH_DISPLAY_TOPIC,NULL)

//////////////////////////////////////////////////////////////////////////
//多个数的最大最小值
#define max3(a,b,c)								((a)>(b)?((a)>(c)?(a):(c)):((b)>(c)?(b):(c)))
#define min3(a,b,c)								((a)<(b)?((a)<(c)?(a):(c)):((b)<(c)?(b):(c)))

//http://blog.csdn.net/djinglan/article/details/8425768
extern int vmax(int n, ...);

//////////////////////////////////////////////////////////////////////////
//颜色转换
template<typename T_REAL>extern void RGBtoHSV(const char R, const char G, const char B, T_REAL &H, T_REAL &S, T_REAL &V);
template<typename T_I8BIT>extern void HSVtoRGB(const float H, const float S, const float V, T_I8BIT &R, T_I8BIT &G, T_I8BIT &B);

//////////////////////////////////////////////////////////////////////////
//读取指定内存
#define GetVarBit(var,n)						(((var)>>(n))&1)
#define GetVarByte(var,n)						(((var)>>(n*sizeof(char)))&0xFF)
